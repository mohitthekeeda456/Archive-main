// src/styles/PageStyles.jsx
import React from "react";

export default function PageStyles() {
  return (
    <style>
      {` /* paste ALL CSS from your PageStyles here unchanged */ `}
    </style>
  );
}
